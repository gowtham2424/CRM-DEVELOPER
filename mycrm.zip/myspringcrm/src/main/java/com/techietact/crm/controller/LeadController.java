package com.techietact.crm.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.techietact.crm.entity.Lead;
import com.techietact.crm.service.LeadService;
import com.techietact.crm.utils.SortUtils;


@Controller
public class LeadController {

    private LeadService leadService;

    @InitBinder
    public void initBinder(WebDataBinder webDataBinder) {
        StringTrimmerEditor trimmer = new StringTrimmerEditor(true);
        webDataBinder.registerCustomEditor(String.class, trimmer);
    }

    @GetMapping("/lead-add")
    public String addLeadPage(Model model) {
        model.addAttribute("lead", new Lead()); // add lead attribute so that on submit spring mvc can call setter on it.
        return "lead-form";
    } 

    @PostMapping("/lead-save")
    public String saveLead(
            @Valid @ModelAttribute("lead") Lead lead,
            BindingResult bindingResult) {
        if (bindingResult.hasErrors()) { // check for any error in lead properties
        	return "lead-form";
        }
        leadService.addLead(lead); 
         // save the lead object in database
        return "redirect:/lead-list";
    }

    @GetMapping("/lead-list")
    public String leadList(@RequestParam(name = "sortBy", required = false) String sortBy , Model model) {
        if (sortBy != null) {
            int sort = Integer.parseInt(sortBy);
            List<Lead> leads = leadService.getLeads(sort);
            model.addAttribute("search", null);
            model.addAttribute("leads", leads);
        } else {
            List<Lead> leads = leadService.getLeads(SortUtils.SortByLastName.getValue()); // get leads list from LeadService class
            model.addAttribute("search", null);
            model.addAttribute("leads", leads); // add leads list in the model
        }
        return "lead-list";
    }

    @GetMapping("/lead-update")
    public String updateLeadPage(@RequestParam("id") int id, Model model) {
        model.addAttribute("lead", leadService.getLead(id)); // add lead attribute with the specific id.
        return "lead-form";
    }

    @GetMapping("/lead-delete")
    public String deleteLead(@RequestParam("id") int id) {
        leadService.deleteLead(id); // delete lead using the LeadService class
        return "redirect:/lead-list";
    }

    @GetMapping("/lead-search")
    public String searchLead(@RequestParam(required = false) String search, Model model) {
        if (search != null) {
            model.addAttribute("search", search);
            model.addAttribute("leads", leadService.searchLead(search));
            return "lead-list";
        }
        return "redirect:/lead-list";
    }

    @Autowired
    public void setLeadDAO(LeadService leadService) {
        this.leadService = leadService;
    }
}
