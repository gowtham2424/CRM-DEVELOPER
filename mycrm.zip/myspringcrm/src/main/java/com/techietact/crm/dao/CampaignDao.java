package com.techietact.crm.dao;

import com.techietact.crm.entity.Campaign;
import java.util.List;



public interface CampaignDao {

	void addCampaign(Campaign campaign);

	Campaign getCampaign(int id);

	List<Campaign> getCampaigns(int sort);

	void deleteCampaign(int id);

	List<Campaign> searchCampaign(String search);

	

}
