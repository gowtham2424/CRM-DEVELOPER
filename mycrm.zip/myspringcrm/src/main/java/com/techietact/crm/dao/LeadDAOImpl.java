package com.techietact.crm.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.techietact.crm.entity.Lead;


@Repository
public class LeadDAOImpl implements LeadDAO {

    private SessionFactory factory;

    @Override
    public void addLead(Lead lead) {
        Session session = factory.getCurrentSession();
        session.saveOrUpdate(lead);
    }

    @Override
    public Lead getLead(int id) {
        Session session = factory.getCurrentSession();
        return session.get(Lead.class, id);
    }

    @Override
    public List<Lead> getLeads(int sortBy) {
        String sort;
        switch (sortBy) {
            case 0: sort = "firstName";
                break;
            case 2: sort = "email";
                break;
            default:
                sort = "lastName";
        }
        Session session = factory.getCurrentSession(); // get hibernate session.
        String queryString = "from Lead order by " + sort;
        Query<Lead> query = session.createQuery(queryString, Lead.class); // create query.
        return query.getResultList(); // execute query and get leads list.
    }

    @Override
    public void deleteLead(int id) {
        Session session = factory.getCurrentSession(); // get hibernate session.
        Query query = session.createQuery("delete from Lead where id=:leadID");
        query.setParameter("leadID", id);
        query.executeUpdate(); // delete the lead from the database.
    }

    @Override
    public List<Lead> searchLead(String searchString) {
        Session session = factory.getCurrentSession();
        Query<Lead> query = session.createQuery("from Lead where firstName like :search or lastName like :search or email like :search", Lead.class);
        searchString = "%" + searchString + "%";
        query.setParameter("search", searchString);
        return query.getResultList();
    }

    @Autowired
    public void setFactory(SessionFactory factory) {
        this.factory = factory;
    }
    
    @Override
    public Lead findByLeadName(String searchString) {
    	//Get Connection
        Session session = factory.getCurrentSession();
        //container
        CriteriaBuilder cb=session.getCriteriaBuilder();
        CriteriaQuery<Lead> cq=cb.createQuery(Lead.class);
        Root<Lead> root=cq.from(Lead.class);
        cq.select(root);
        cq.where(cb.equal(root.get("firstName"), searchString));
        Lead leads=session.createQuery(cq).uniqueResult();
        return leads;
    }
    
    
}
