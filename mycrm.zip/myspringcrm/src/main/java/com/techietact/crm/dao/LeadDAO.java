package com.techietact.crm.dao;

import java.util.List;

import com.techietact.crm.entity.Lead;


public interface LeadDAO {

    /**
     * Method to add {@link Lead} object in database.
     * @param lead - {@link Lead} object which has to add in database.
     */
    void addLead(Lead lead);

    /**
     * @param id - id of the {@link Lead} object.
     * @return - {@link Lead} object which is retrieved from database.
     */
    Lead getLead(int id);

    /**
     * Getter method for retrieving the leads list from database.
     * @param sortBy - get list of {@link Lead} in sorted manner based on sortBy.
     * @return - list of {@link Lead}
     */
    List<Lead> getLeads(int sortBy);

    /**
     * Method to delete the {@link Lead} object with the id from the database.
     * @param id - used to retrieve the {@link Lead} object from the database.
     */
    void deleteLead(int id);

    /**
     * Method to search {@link Lead} based on searchString.
     * @param searchString - pattern to be search in firstName, lastName and email.
     * @return - list of {@link Lead} which have the given String in their property.
     */
    List<Lead> searchLead(String searchString);

	Lead findByLeadName(String searchString);
}
