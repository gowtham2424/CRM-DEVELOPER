package com.techietact.crm.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.techietact.crm.entity.Campaign;
import com.techietact.crm.entity.Product;
import com.techietact.crm.service.CampaignService;
import com.techietact.crm.utils.SortUtils;

@Controller

public class CampaignController {
	
	private CampaignService campaignService;
	
	@InitBinder
	public void initBinder(WebDataBinder webDataBinder) {
        StringTrimmerEditor trimmer = new StringTrimmerEditor(true);
        webDataBinder.registerCustomEditor(String.class, trimmer);
	}
	
	@GetMapping("/campaign-add")
	public String addCampaign(Model model) {
		model.addAttribute("productsList",getProducts());		
		model.addAttribute("campaign", new Campaign());
		return "campaign-form";
	}
	
	
	private Map<Integer,String> getProducts() {
		Map<Integer,String> productsList=new HashMap<Integer,String>();
		productsList.put(1,"Punch");
		productsList.put(2, "TataNano");
		productsList.put(3, "Celerio");
		productsList.put(4, "Tiago");
		productsList.put(5, "Kwid");
		
		return productsList;
	}

	@PostMapping("/campaign-save")
	public String saveCampaign(@Valid @ModelAttribute("campaign")Campaign campaign,
	BindingResult bindingResult) {
		if(bindingResult.hasErrors()) {
			return "campaign-form";
		}
		campaignService.addCampaign(campaign);
		return "redirect:/campaign-list";
		
	}

	@GetMapping("/campaign-list")
    public String campaignlist(@RequestParam(name = "sortBy", required = false) String sortBy , Model model) {
        if (sortBy != null) {
            int sort = Integer.parseInt(sortBy);
            List<Campaign> campaign = campaignService.getCampaigns(sort);
            model.addAttribute("search", null);
            model.addAttribute("campaign", campaign);
        } else {
            List<Campaign> campaign = campaignService.getCampaigns(SortUtils.SortByCampaignName.getValue()); // get leads list from LeadService class
            model.addAttribute("search", null);
            model.addAttribute("campaign", campaign); // add leads list in the model
        }
        return "campaign-list";
    }

    @GetMapping("/campaign-update")
    public String updatecampaign(@RequestParam("campaignId") int campaignId, Model model) {
        model.addAttribute("campaign", campaignService.getCampaign(campaignId)); // add lead attribute with the specific id.
        return "campaign-form";
    }

    @GetMapping("/campaign-delete")
    public String deleteCampaign(@RequestParam("campaignId") int campaignId) {
    	campaignService.deleteCampaign(campaignId); // delete lead using the LeadService class
        return "redirect:/campaign-list";
    }

    @GetMapping("/campaign-search")
    public String searchCampaign(@RequestParam(required = false) String search, Model model) {
        if (search != null) {
            model.addAttribute("search", search);
            model.addAttribute("campaigns", campaignService.searchCampaign(search));
            return "campaign-list";
        }
        return "redirect:/campaign-list";
    }

	@Autowired
    public void setCampaignDAO(CampaignService campaignService) {
        this.campaignService = campaignService;		
	
	
}
}
