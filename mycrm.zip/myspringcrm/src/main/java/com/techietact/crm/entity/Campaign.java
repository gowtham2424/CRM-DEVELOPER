package com.techietact.crm.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

@Entity
@Table(name= "campaign")

public class Campaign {

	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
    @Column(name = "campaign_id")
    private int campaignId;

	@Column(name="campaign_name")
	@NotNull(message="Campaign_name is Mandatory!")
	private String campaignName;
	
	@Column(name="start_date")
	@NotNull(message="Start_date is Mandatory!")
	private String startDate;
	
	@Column(name="end_date")
	@NotNull(message="End_date is Mandatory!")
	private String endDate;
	
	@Column(name="status")
	@NotNull(message="Status is Mandatory!")
	private String status;
	
	@Column(name="owner")
	@NotNull(message="Owner is Mandatory!")
	private String owner;
	
	@Column(name="budget")
	@NotNull(message="Budget is Mandatory!")
	private long budget;
	
	@Column(name="remarks")
	private String remarks;
	
	@Column(name="approval_status")
	private String approvalStatus;
	
	@ManyToMany
	private List<Product> product;
	
	@Transient
	private String products;
	
	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

	public String getProducts() {
		return products;
	}

	public void setProducts(String products) {
		this.products = products;
	}

	public Campaign() {		
	}
	
	public Campaign(String campaignName,String startDate,String endDate, String status,String owner,long budget,String remarks,String approvalStatus) {
	this.campaignName=campaignName;
	this.startDate=startDate;
	this.endDate=endDate;
	this.status=status;
	this.owner=owner;
	this.budget=budget;
	this.remarks=remarks;
	this.approvalStatus=approvalStatus;	
	}

	
	public int getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(int campaignId) {
		this.campaignId = campaignId;
	}
	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	/*
	 * public int getId() { return id; }
	 * 
	 * public void setId(int id) { this.id = id; }
	 */

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	/*
	 * public Date getStartDate() { return startDate; }
	 * 
	 * public void setStartDate(Date startDate) { this.startDate = startDate; }
	 * 
	 * public Date getEndDate() { return endDate; }
	 * 
	 * public void setEndDate(Date endDate) { this.endDate = endDate; }
	 */

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public long getBudget() {
		return budget;
	}

	public void setBudget(long budget) {
		this.budget = budget;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}
	
	@Override
    public String toString() {
        return "Campaign{" + "campaignId=" + campaignId +
                ", campaignName='" + campaignName + '\'' +
                ", startDate='" + startDate + '\'' +
                ", endDate='" + endDate + '\'' +
                ", status='" + status + '\'' +
                                ", owner='" + owner + '\'' +
                ", budget='" + budget + '\'' +
                ", remarks='" + remarks + '\'' +
                ", approvalStatus='" + approvalStatus + '\'' +   
                '}';
    }	
}
