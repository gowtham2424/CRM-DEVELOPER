package com.techietact.crm.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.techietact.crm.entity.Campaign;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.techietact.crm.entity.Lead;
@Repository

public class CampaignDaoImpl implements CampaignDao {
	
	private SessionFactory factory;

	@Override
	public void addCampaign(Campaign campaign) {
		Session session=factory.getCurrentSession();
		session.saveOrUpdate(campaign);
	}
	@Override
	public Campaign getCampaign(int campaignId) {
		Session session=factory.getCurrentSession();
		return session.get(Campaign.class, campaignId);
	}

	@Override
	public void deleteCampaign(int campaignId) {
	Session session=factory.getCurrentSession();
	Query query=session.createQuery("delete from Campaign where id=:campaignID");
			query.setParameter("campaignID", campaignId);
	query.executeUpdate();
	}

	
	@Override
	public List<Campaign> getCampaigns(int sortBy) {
		String sort;
		switch(sortBy) {
		case 0: sort="startDate";
		break;
		case 1: sort="endDate";
		break;
		case 2:sort="owner";
		break;
		case 4:sort="status";
		break;
		case 5:sort="budget";
		break;
		case 6:sort="remarks";
		break;
		case 7:sort="approvalStatus";
		break;
		default:
			sort="campaignName";
		
		}
		Session session = factory.getCurrentSession(); // get hibernate session.
        String queryString = "from Campaign order by " + sort;
        Query<Campaign> query = session.createQuery(queryString, Campaign.class); // create query.
        return query.getResultList();
	}
	@Override
	public List<Campaign> searchCampaign(String search) {
		Session session = factory.getCurrentSession();
        Query<Campaign> query = session.createQuery("from Campaign where campaignName like :search or startDate like :search or endDate like :search or owner like :search or status like :search or budget like :search or remarks like :search or approvalStatus like :search", Campaign.class);
       search = "%" + search + "%";
       query.setParameter("search", search);
        return query.getResultList();
	}
	
	@Autowired
    public void setFactory(SessionFactory factory) {
        this.factory = factory;
    }

}
