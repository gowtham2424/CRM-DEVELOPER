package com.techietact.crm.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.techietact.crm.dao.CampaignDao;
import com.techietact.crm.entity.Campaign;
import com.techietact.crm.entity.Product;

@Service
public class CampaignServiceImpl implements CampaignService {

	
	private CampaignDao campaignDao;
	
	@Override
	@Transactional
	public void addCampaign(Campaign campaign) {
		String[] selectedProducts=null;
		List<Product> selectedPro=new ArrayList<Product>();
		if(null!=campaign && null!=campaign.getProducts()) {
		selectedProducts=campaign.getProducts().split(",");
		
		for(String s:selectedProducts) {
			long productId=new Integer(s);
			Product p=new Product();
			p.setProductId(productId);
			selectedPro.add(p);
					}
		
		campaign.setProduct(selectedPro);
	}
		campaignDao.addCampaign(campaign);
		
	}

	@Override
	@Transactional
	public Campaign getCampaign(int id) {
		return campaignDao.getCampaign(id);
	}

	@Override
	@Transactional
	public List<Campaign> getCampaigns(int sort) {
		return campaignDao.getCampaigns(sort);
		
	}

	@Override
	@Transactional
	public void deleteCampaign(int id) {
		campaignDao.deleteCampaign(id);
		
	}

	@Override
	@Transactional
	public List<Campaign> searchCampaign(String search) {
				return campaignDao.searchCampaign(search);
	}

	@Autowired
    public void setCampaignDao(CampaignDao campaignDao) {
        this.campaignDao = campaignDao;
    }
	
}
