package com.techietact.crm.service;

import java.util.List;

import com.techietact.crm.entity.Campaign;

public interface CampaignService {

	void addCampaign(Campaign campaign);

	List<Campaign> getCampaigns(int sort);

	Campaign getCampaign(int id);

	void deleteCampaign(int id);

	List<Campaign> searchCampaign(String search);

}
